echo "working directory: "
read mypath

if [ ! -d "$mypath" -o ! -x "$mypath" ]; then
        echo "$mypath doesn't exist or permission denied."
else
        j=1
        for i in *
                do
                        while [ $j -le ${#i} ]
                                do
                                        mychar=`echo $i |cut -c$j-$j`
                                        if [ -z "$(echo "$mychar" | sed -E 's/[[:lower:]]//')" ]; then
                                                mychar="$(echo $mychar | tr '[[:lower:]]' '[[:upper:]]')"
                                                newchar=$newchar$mychar
                                        elif [ -z "$(echo "$mychar" | sed -E 's/[[:upper:]]//')" ]; then
                                                mychar="$(echo $mychar | tr '[[:upper:]]' '[[:lower:]]')"
                                                newchar=$newchar$mychar
                                        else
                                                newchar=$newchar$mychar
                                        fi
                                        j=`expr $j + 1`
                        done
                        j=1
                        mv $i $newchar
                        newchar=""
                done
fi

